package com.example.bottam_ex.data.model;

public class CheckEmailResponse {
    public boolean isDuplicate;
}

