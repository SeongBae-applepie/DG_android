package com.example.bottam_ex.data.model;

public class TokenResponse {
    public String accessToken;
}