package com.example.bottam_ex.data.model;

public class User {
    public int id;

    public String name;
    public String email;
    public String role;
    public String created_at;
}