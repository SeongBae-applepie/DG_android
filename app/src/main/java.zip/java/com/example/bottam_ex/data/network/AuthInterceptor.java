package com.example.bottam_ex.data.network;

public class AuthInterceptor {
}
