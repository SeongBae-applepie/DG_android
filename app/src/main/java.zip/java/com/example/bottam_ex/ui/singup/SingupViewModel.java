package com.example.bottam_ex.ui.singup;

import androidx.lifecycle.ViewModel;

public class SingupViewModel extends ViewModel {
    public void signup(String email, String password) {
        // TODO: Retrofit 호출로 서버 회원가입 연동
    }
}
